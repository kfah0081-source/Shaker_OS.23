/// =============================================================
/// Shaker OS — الشاشة الرئيسية (Zen Mode)
/// =============================================================
/// الوضع الافتراضي: لا تعقيد. شريط توكيدات، زر ذكر ديناميكي
/// بنص قابل للتخصيص، عداد بأرقام إنجليزية، مؤشر نطاق دماغي،
/// وعداد "طول الأثر" التنازلي، وخلفية موجات حية.
library;

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../engine/brainwave_engine.dart';
import '../../engine/models/session_models.dart';
import '../../themes/app_themes.dart';
import '../../widgets/affirmation_carousel.dart';
import '../../widgets/dhikr_button.dart';
import '../../widgets/wave_background.dart';
import 'zen_controller.dart';

/// نص الذكر على الزر — قابل للتخصيص من الإعدادات.
final dhikrLabelProvider = StateProvider<String>((ref) => 'سبحان الله');

/// الثيم الحالي.
final themeProvider = StateProvider<ShakerTheme>((ref) => ShakerTheme.sakina);

class ZenScreen extends ConsumerWidget {
  const ZenScreen({super.key});

  String _formatCounter(int n) =>
      n.toString(); // أرقام إنجليزية بشكل صريح (PRD §4)

  String _formatDuration(Duration d) {
    final h = d.inHours;
    final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return h > 0 ? '$h:$m:$s' : '$m:$s';
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final session = ref.watch(zenControllerProvider);
    final controller = ref.read(zenControllerProvider.notifier);
    final label = ref.watch(dhikrLabelProvider);
    final palette = ref.watch(themeProvider).palette;

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [palette.backgroundTop, palette.backgroundBottom],
            ),
          ),
          child: Stack(
            children: [
              // الخلفية: موجات حية تتبع النطاق الدماغي.
              Positioned.fill(
                child: WaveBackground(
                  band: session.band,
                  coherence: session.coherence,
                  waveColors: palette.waveColors,
                ),
              ),

              SafeArea(
                child: Column(
                  children: [
                    const SizedBox(height: 8),

                    // شريط التوكيدات + الرسائل التفاعلية.
                    AffirmationCarousel(
                      band: session.band,
                      transition: session.justEnteredBand,
                      suggestedDhikr: session.suggestedDhikr,
                      textColor: palette.textMuted,
                      accentColor: palette.accent,
                    ),

                    // مؤشر النطاق الدماغي + التردد المحاكى.
                    _BandIndicator(session: session, palette: palette),

                    const Spacer(),

                    // زر الذكر الديناميكي.
                    DhikrButton(
                      label: label,
                      onTap: controller.onTap,
                      coherence: session.coherence,
                      accentColor: palette.accent,
                      textColor: palette.textPrimary,
                    ),

                    const SizedBox(height: 16),

                    // العداد الرئيسي (أرقام إنجليزية).
                    Text(
                      _formatCounter(session.tapCount),
                      style: Theme.of(context).textTheme.displayLarge?.copyWith(
                            color: palette.textPrimary,
                            fontFeatures: const [],
                          ),
                    ),

                    const Spacer(),

                    // عداد طول الأثر + حالة الإيقاف الذكي.
                    _EffectFooter(
                      session: session,
                      palette: palette,
                      format: _formatDuration,
                    ),

                    const SizedBox(height: 16),
                  ],
                ),
              ),

              // اقتراح الجهر عند الحاجة (كافيين/توتر).
              if (session.recommendLoudMode && session.band == BrainwaveBand.beta)
                Positioned(
                  bottom: 110,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: Text(
                      'جرّب الذكر الجهري لكسر حاجز التوتر',
                      style: TextStyle(color: palette.accentSecondary),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

/// شريط علوي صغير: اسم النطاق + التردد المحاكى + شريط تقدم الانسجام.
class _BandIndicator extends StatelessWidget {
  const _BandIndicator({required this.session, required this.palette});

  final SessionState session;
  final ShakerPalette palette;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'نطاق ${session.band.arabicName}',
                style: TextStyle(color: palette.accent, fontSize: 15),
              ),
              Text(
                '${session.simulatedHz.toStringAsFixed(1)} Hz',
                style: TextStyle(
                  color: palette.textMuted,
                  fontSize: 13,
                  fontFamily: 'monospace',
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: session.coherence,
              minHeight: 4,
              backgroundColor: palette.accentSecondary.withValues(alpha: 0.2),
              valueColor: AlwaysStoppedAnimation(palette.accent),
            ),
          ),
        ],
      ),
    );
  }
}

/// تذييل: رصيد طول الأثر + حالة العداد (حي / موقوف ذكياً).
class _EffectFooter extends StatelessWidget {
  const _EffectFooter({
    required this.session,
    required this.palette,
    required this.format,
  });

  final SessionState session;
  final ShakerPalette palette;
  final String Function(Duration) format;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        if (session.halted)
          Padding(
            padding: const EdgeInsets.only(bottom: 6),
            child: Text(
              'العداد متوقف — انقر للاستئناف',
              style: TextStyle(color: palette.accentSecondary, fontSize: 12),
            ),
          ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            color: palette.accent.withValues(alpha: 0.08),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.self_improvement, size: 16, color: palette.accent),
              const SizedBox(width: 8),
              Text(
                'طول الأثر المتبقي: ${format(session.effectRemaining)}',
                style: TextStyle(color: palette.textPrimary, fontSize: 13),
              ),
            ],
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'الزمن الحي: ${format(session.activeElapsed)}  •  '
          'انتظام النقر: ${(session.regularity * 100).round()}%',
          style: TextStyle(color: palette.textMuted, fontSize: 11),
        ),
      ],
    );
  }
}
