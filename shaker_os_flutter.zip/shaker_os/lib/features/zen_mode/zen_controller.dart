/// =============================================================
/// Shaker OS — وحدة تحكم جلسة Zen (Riverpod)
/// =============================================================
/// الغراء بين المحرك الخامد (BrainwaveEngine) والواجهة:
/// مؤقّت 100ms يقود tick()، ويوزّع اللقطات على الواجهة.
library;

import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../engine/bio_clock.dart';
import '../../engine/brainwave_engine.dart';
import '../../engine/models/session_models.dart';
import '../../engine/multipliers.dart';

/// المُدخلات الحالية للمستخدم (تُحدَّث من شاشة الاستبيان الاختياري).
final userInputsProvider =
    StateProvider<UserInputs>((ref) => const UserInputs());

/// الكنترولر الرئيسي للجلسة.
final zenControllerProvider =
    StateNotifierProvider<ZenController, SessionState>((ref) {
  final inputs = ref.watch(userInputsProvider);
  return ZenController(inputs);
});

class ZenController extends StateNotifier<SessionState> {
  ZenController(UserInputs inputs)
      : _engine = BrainwaveEngine(
          modifiers: const BioClock()
              .modifiersFor(DateTime.now())
              .merge(computeModifiers(inputs)),
        ),
        super(
          SessionState(
            band: BrainwaveBand.beta,
            coherence: 0,
            simulatedHz: 30,
            elapsed: Duration.zero,
            activeElapsed: Duration.zero,
            tapCount: 0,
            effectRemaining: Duration.zero,
            halted: false,
            regularity: 0,
            suggestedDhikr: const [],
            recommendLoudMode: false,
            needsAlertnessDhikr: false,
            justEnteredBand: null,
          ),
        ) {
    _ticker = Timer.periodic(const Duration(milliseconds: 100), (_) {
      state = _engine.tick(DateTime.now());
    });
  }

  final BrainwaveEngine _engine;
  Timer? _ticker;

  void onTap() {
    _engine.onTap(DateTime.now());
    // لقطة فورية لاستجابة بصرية لحظية (بدون انتظار النبضة القادمة).
    state = _engine.snapshot(DateTime.now());
  }

  /// الإدخال بأثر رجعي (Offline Sync).
  ({Duration simulatedDuration, Duration effectGained}) applyRetroactive({
    int? tapCount,
    Duration? duration,
  }) {
    final avgIti = _engine.averageItiMs ?? 900.0; // افتراضي ≈ نقرة/ثانية
    final result = _engine.applyRetroactive(
      tapCount: tapCount,
      duration: duration,
      avgItiMs: avgIti,
    );
    state = _engine.snapshot(DateTime.now());
    return result;
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }
}
