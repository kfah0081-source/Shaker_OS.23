import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'features/zen_mode/zen_screen.dart';

/// التطبيق الجذري: يطبّق الثيم المختار ويفتح مباشرة على
/// Zen Mode (الوضع الافتراضي — بلا استبيان إجباري).
class ShakerApp extends ConsumerWidget {
  const ShakerApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = ref.watch(themeProvider);
    return MaterialApp(
      title: 'Shaker OS',
      debugShowCheckedModeBanner: false,
      theme: theme.materialTheme,
      home: const ZenScreen(),
    );
  }
}
