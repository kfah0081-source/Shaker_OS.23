/// =============================================================
/// Shaker OS — الثيمات الأربعة (PRD §4)
/// =============================================================
library;

import 'package:flutter/material.dart';

enum ShakerTheme {
  /// استخباراتي: داكن جداً، رادار بياني، نبض أخضر نيون.
  intelligence,

  /// أمني: أزرق داكن وفضي، صارم وحاد.
  security,

  /// قيادي: ذهبي/كحلي ملكي.
  leader,

  /// السكينة: باستيل سماوي/أبيض متدرج يتنفس ببطء.
  sakina,
}

class ShakerPalette {
  const ShakerPalette({
    required this.backgroundTop,
    required this.backgroundBottom,
    required this.accent,
    required this.accentSecondary,
    required this.textPrimary,
    required this.textMuted,
    required this.waveColors,
  });

  final Color backgroundTop;
  final Color backgroundBottom;
  final Color accent;
  final Color accentSecondary;
  final Color textPrimary;
  final Color textMuted;

  /// ألوان طبقات الموجات الحية في الخلفية (3 طبقات).
  final List<Color> waveColors;
}

extension ShakerThemeX on ShakerTheme {
  String get arabicName => switch (this) {
        ShakerTheme.intelligence => 'استخباراتي',
        ShakerTheme.security => 'أمني',
        ShakerTheme.leader => 'قيادي',
        ShakerTheme.sakina => 'السكينة',
      };

  ShakerPalette get palette => switch (this) {
        ShakerTheme.intelligence => const ShakerPalette(
            backgroundTop: Color(0xFF030807),
            backgroundBottom: Color(0xFF0A1410),
            accent: Color(0xFF39FF88), // أخضر نيون
            accentSecondary: Color(0xFF1B5E3A),
            textPrimary: Color(0xFFE8FFF2),
            textMuted: Color(0xFF5A7A68),
            waveColors: [
              Color(0x2239FF88),
              Color(0x1527C46F),
              Color(0x0A1B5E3A),
            ],
          ),
        ShakerTheme.security => const ShakerPalette(
            backgroundTop: Color(0xFF0A1220),
            backgroundBottom: Color(0xFF12203A),
            accent: Color(0xFFC0CCD8), // فضي
            accentSecondary: Color(0xFF3D5A80),
            textPrimary: Color(0xFFF0F4F8),
            textMuted: Color(0xFF6B7E94),
            waveColors: [
              Color(0x223D5A80),
              Color(0x152E4763),
              Color(0x0A1E3049),
            ],
          ),
        ShakerTheme.leader => const ShakerPalette(
            backgroundTop: Color(0xFF10162E),
            backgroundBottom: Color(0xFF1A2242), // كحلي ملكي
            accent: Color(0xFFD4AF37), // ذهبي
            accentSecondary: Color(0xFF8C7326),
            textPrimary: Color(0xFFFBF6E9),
            textMuted: Color(0xFF8E8A76),
            waveColors: [
              Color(0x22D4AF37),
              Color(0x15A8892D),
              Color(0x0A6E5B1F),
            ],
          ),
        ShakerTheme.sakina => const ShakerPalette(
            backgroundTop: Color(0xFFEAF6FB),
            backgroundBottom: Color(0xFFCFEAF5), // سماوي متدرج
            accent: Color(0xFF4FA8C9),
            accentSecondary: Color(0xFF9AD1E4),
            textPrimary: Color(0xFF1E3A47),
            textMuted: Color(0xFF7FA3B0),
            waveColors: [
              Color(0x404FA8C9),
              Color(0x307FBDD8),
              Color(0x209AD1E4),
            ],
          ),
      };

  ThemeData get materialTheme {
    final p = palette;
    final dark = this != ShakerTheme.sakina;
    return ThemeData(
      useMaterial3: true,
      brightness: dark ? Brightness.dark : Brightness.light,
      scaffoldBackgroundColor: p.backgroundBottom,
      colorScheme: ColorScheme.fromSeed(
        seedColor: p.accent,
        brightness: dark ? Brightness.dark : Brightness.light,
      ).copyWith(primary: p.accent, surface: p.backgroundBottom),
      textTheme: TextTheme(
        displayLarge: TextStyle(
          color: p.textPrimary,
          fontSize: 64,
          fontWeight: FontWeight.w200,
          letterSpacing: 2,
        ),
        titleLarge: TextStyle(color: p.textPrimary, fontSize: 20),
        bodyMedium: TextStyle(color: p.textMuted, fontSize: 14),
      ),
    );
  }
}
