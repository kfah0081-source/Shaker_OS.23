/// =============================================================
/// Shaker OS — الاستنتاج الآلي للمناخ (Bio-Clock)
/// =============================================================
/// يضبط المقاومة الافتراضية للخوارزمية بناءً على التوقيت المحلي:
/// ليل/نهار، وشتاء/صيف (PRD §5 — Advanced Features).
library;

import 'multipliers.dart';

class BioClock {
  const BioClock();

  /// مُعاملات المناخ لحظة الاستدعاء.
  EngineModifiers modifiersFor(DateTime now) {
    final hour = now.hour;
    final month = now.month;

    // نصف كرة شمالي افتراضياً: شتاء = ديسمبر..فبراير.
    final isWinter = month == 12 || month <= 2;

    final isNight = hour >= 21 || hour < 5;
    final isDawn = hour >= 4 && hour < 6;
    final isLateAfternoon = hour >= 16 && hour < 19;

    var betaResistance = 1.0;
    var thetaSpeed = 1.0;
    var alphaStability = 1.0;

    if (isNight) {
      // الليل: الجهاز العصبي مهيأ للهدوء → مقاومة أقل.
      betaResistance *= 0.9;
      thetaSpeed *= 1.1;
    }
    if (isDawn) {
      // نافذة الفجر: حساسية روحية عالية.
      thetaSpeed *= 1.2;
      betaResistance *= 0.85;
    }
    if (isLateAfternoon) {
      // ذروة الإرهاق اليومي: مقاومة أعلى قليلاً.
      betaResistance *= 1.1;
    }
    if (isWinter) {
      // شتاء: ميل طبيعي للخمول → نحتاج تثبيت ألفا أعلى.
      alphaStability *= 0.95;
      betaResistance *= 1.05;
    }

    return EngineModifiers(
      betaExitResistance: betaResistance,
      thetaEntrySpeed: thetaSpeed,
      alphaStability: alphaStability,
    );
  }
}
