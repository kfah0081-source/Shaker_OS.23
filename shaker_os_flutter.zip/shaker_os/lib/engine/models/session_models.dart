/// =============================================================
/// Shaker OS — نماذج البيانات الأساسية (Core Domain Models)
/// =============================================================
/// هذا الملف يعرّف كل المُدخلات التي يقرأها المحرك الخوارزمي:
/// الحالة النفسية، الفيزيائية، الكيميائية، الهرمونية، والروحية.
/// كل التعدادات والنماذج هنا "خام" (بلا منطق) — المنطق كله في
/// المحرك (engine/brainwave_engine.dart) وحاسبة المُعاملات
/// (engine/multipliers.dart).
library;

// -------------------------------------------------------------
// 1. ترددات الدماغ (Brainwave Bands)
// -------------------------------------------------------------
enum BrainwaveBand {
  /// بيتا: 13–30 Hz — البداية، النشاط، التوتر.
  beta,

  /// ألفا: 8–12 Hz — الاسترخاء والتناغم (بعد انتظام النقر).
  alpha,

  /// ثيتا: 4–8 Hz — التأمل والتشافي العميق (استمرار دون انقطاع).
  theta,
}

extension BrainwaveBandX on BrainwaveBand {
  /// النطاق الترددي المعروض على الواجهة (محاكاة).
  (double minHz, double maxHz) get hzRange => switch (this) {
        BrainwaveBand.beta => (13.0, 30.0),
        BrainwaveBand.alpha => (8.0, 12.0),
        BrainwaveBand.theta => (4.0, 8.0),
      };

  String get arabicName => switch (this) {
        BrainwaveBand.beta => 'بيتا',
        BrainwaveBand.alpha => 'ألفا',
        BrainwaveBand.theta => 'ثيتا',
      };
}

// -------------------------------------------------------------
// 2. الحالة النفسية (Psychological State)
// -------------------------------------------------------------
enum PsychologicalState {
  /// متوتر: بيتا العالي — تباطؤ منطقي في النزول للسكينة.
  stressed,

  /// متعب: ميل نحو النعاس (دلتا) — تقترح الخوارزمية أذكار اليقظة.
  tired,

  /// مسترخي: الدماغ في ألفا — تسريع الدخول في ثيتا.
  relaxed,

  /// ممتن: كالمسترخي مع دفعة تماسك إضافية.
  grateful,

  /// محايد (الوضع الافتراضي عند تخطي الاستبيان).
  neutral,
}

// -------------------------------------------------------------
// 3. الحالة الفيزيائية والصوتية (Physical State)
// -------------------------------------------------------------
enum PhysicalMode {
  /// صامت (ذهني فقط).
  silent,

  /// همس: يعزل الحواس الخارجية — يسرّع الغوص في ثيتا.
  whisper,

  /// جهر: يحفّز العصب المبهم ميكانيكياً — يكسر حاجز بيتا بسرعة.
  loud,

  /// سجود طويل: يضاعف نقاط طول الأثر ×5 (أكسجة الفص الجبهي).
  longSujood,
}

/// تفاصيل جلسة السجود الطويل (تُدخل عند اختيار PhysicalMode.longSujood).
class SujoodDetails {
  const SujoodDetails({
    required this.totalDuration,
    required this.dhikrDuration,
    required this.duaDuration,
  });

  /// وقت السجود الكلي.
  final Duration totalDuration;

  /// وقت الذكر أثناء السجود.
  final Duration dhikrDuration;

  /// وقت الدعاء أثناء السجود.
  final Duration duaDuration;

  /// نسبة الالتزام الفعلي بالذكر/الدعاء من إجمالي السجود (0..1).
  /// تُستخدم لترجيح مُضاعف ×5: سجود بلا ذكر لا يأخذ المضاعف كاملاً.
  double get engagementRatio {
    if (totalDuration.inSeconds <= 0) return 0;
    final engaged = dhikrDuration.inSeconds + duaDuration.inSeconds;
    return (engaged / totalDuration.inSeconds).clamp(0.0, 1.0);
  }
}

// -------------------------------------------------------------
// 4. الكيمياء الحيوية والمكملات (Biochemical Inputs)
// -------------------------------------------------------------
enum Supplement {
  /// كافيين/منبهات: مقاومة كيميائية تمنع النزول السريع من بيتا.
  caffeine,

  /// مغنيسيوم جلايسينات: درع استقرار — يسرّع النزول إلى ثيتا.
  magnesiumGlycinate,

  /// أوميغا 3: انسجام دماغي — يسرّع ثيتا.
  omega3,

  /// كرياتين: يمنع الإرهاق الذهني — يثبّت ألفا اليقظة.
  creatine,

  /// زنك: دعم استقرار ألفا للجلسات الطويلة.
  zinc,

  /// زيت زيتون: دعم عام للوضوح الذهني.
  oliveOil,
}

// -------------------------------------------------------------
// 5. الهرمونات والطاقة الحيوية (Endocrine / Dopamine)
// -------------------------------------------------------------
enum MaritalStatus { single, married }

// -------------------------------------------------------------
// 6. المنظومة الروحية (Spiritual State)
// -------------------------------------------------------------
enum WorshipTiming {
  /// تم مسبقاً (يرفع نقطة بداية المؤشر).
  doneBefore,

  /// سيتم لاحقاً (يؤثر على نوعية الأذكار المقترحة).
  plannedLater,

  /// غير محدد.
  none,
}

/// حزمة المُدخلات الكاملة التي يبنيها "الاستبيان الاختياري".
/// كل الحقول لها قيم افتراضية آمنة حتى يعمل Zen Mode بلا استبيان.
class UserInputs {
  const UserInputs({
    this.psychological = PsychologicalState.neutral,
    this.physical = PhysicalMode.silent,
    this.sujood,
    this.supplements = const {},
    this.maritalStatus = MaritalStatus.single,
    this.retentionDays = 0,
    this.isFasting = false,
    this.gaveCharity = false,
    this.quranStatus = WorshipTiming.none,
    this.qiyamStatus = WorshipTiming.none,
  });

  final PsychologicalState psychological;
  final PhysicalMode physical;
  final SujoodDetails? sujood;
  final Set<Supplement> supplements;

  // الهرمونات والدوبامين
  final MaritalStatus maritalStatus;

  /// عداد أيام الاحتفاظ بالطاقة الجسدية (X).
  final int retentionDays;

  // المنظومة الروحية
  final bool isFasting;
  final bool gaveCharity;
  final WorshipTiming quranStatus;
  final WorshipTiming qiyamStatus;

  UserInputs copyWith({
    PsychologicalState? psychological,
    PhysicalMode? physical,
    SujoodDetails? sujood,
    Set<Supplement>? supplements,
    MaritalStatus? maritalStatus,
    int? retentionDays,
    bool? isFasting,
    bool? gaveCharity,
    WorshipTiming? quranStatus,
    WorshipTiming? qiyamStatus,
  }) {
    return UserInputs(
      psychological: psychological ?? this.psychological,
      physical: physical ?? this.physical,
      sujood: sujood ?? this.sujood,
      supplements: supplements ?? this.supplements,
      maritalStatus: maritalStatus ?? this.maritalStatus,
      retentionDays: retentionDays ?? this.retentionDays,
      isFasting: isFasting ?? this.isFasting,
      gaveCharity: gaveCharity ?? this.gaveCharity,
      quranStatus: quranStatus ?? this.quranStatus,
      qiyamStatus: qiyamStatus ?? this.qiyamStatus,
    );
  }
}
