/// =============================================================
/// Shaker OS — المحرك الخوارزمي الأساسي (Brainwave Engine)
/// =============================================================
/// المسؤوليات:
///   1. تحليل سرعة النقر وانتظامه (Inter-Tap Interval + CV).
///   2. قيادة مؤشر "الانسجام" (coherence: 0..1) عبر نطاقات
///      بيتا ← ألفا ← ثيتا وفق المُعاملات.
///   3. احتساب "طول الأثر" (رصيد السكينة بالثواني).
///   4. الإيقاف الذكي: توقف > 30 ثانية = تجميد فوري للعداد.
///   5. الإدخال بأثر رجعي (Offline Sync) عبر المحاكاة الإحصائية.
///
/// المحرك "خامل" (passive): لا يملك Timer بنفسه — الواجهة
/// (ZenController) تستدعي tick() كل 100ms وتستدعي onTap()
/// عند كل نقرة. هذا يجعله قابلاً للاختبار بالكامل (unit-testable).
library;

import 'dart:math' as math;

import 'models/session_models.dart';
import 'multipliers.dart';

/// لقطة حالة الجلسة في لحظة زمنية — تُقرأ مباشرة من الواجهة.
class SessionState {
  const SessionState({
    required this.band,
    required this.coherence,
    required this.simulatedHz,
    required this.elapsed,
    required this.activeElapsed,
    required this.tapCount,
    required this.effectRemaining,
    required this.halted,
    required this.regularity,
    required this.suggestedDhikr,
    required this.recommendLoudMode,
    required this.needsAlertnessDhikr,
    required this.justEnteredBand,
  });

  final BrainwaveBand band;

  /// مؤشر الانسجام 0..1 (يقود كل شيء).
  final double coherence;

  /// التردد المحاكى المعروض (Hz) ضمن نطاق النطاق الحالي.
  final double simulatedHz;

  /// الزمن الكلي منذ بدء الجلسة (يشمل فترات التوقف).
  final Duration elapsed;

  /// الزمن "الحي" فقط (بدون فترات الإيقاف الذكي).
  final Duration activeElapsed;

  final int tapCount;

  /// طول الأثر المتبقي: رصيد السكينة بعد إغلاق التطبيق.
  final Duration effectRemaining;

  /// هل العداد مجمّد بسبب الإيقاف الذكي؟
  final bool halted;

  /// انتظام النقر الحالي 0..1 (1 = إيقاع مثالي).
  final double regularity;

  final List<String> suggestedDhikr;
  final bool recommendLoudMode;
  final bool needsAlertnessDhikr;

  /// true لدورة واحدة فقط عند لحظة الانتقال لنطاق جديد —
  /// تستخدمها الواجهة لإطلاق رسالة تفاعلية (مثلاً "دخلت ألفا").
  final BrainwaveBand? justEnteredBand;
}

class BrainwaveEngine {
  BrainwaveEngine({required this.modifiers, DateTime? startTime})
      : _startTime = startTime ?? DateTime.now() {
    _coherence = modifiers.startCoherence.clamp(0.0, 0.55);
    // الدفعة الفورية (صيام/صدقة/مغنيسيوم) تُطبق مرة واحدة عند البدء.
    _coherence =
        (_coherence + modifiers.instantCoherenceBoost).clamp(0.0, 1.0);
  }

  final EngineModifiers modifiers;

  // ------------------------------------------------------------
  // ثوابت الخوارزمية (كلها قابلة للمعايرة لاحقاً من ملف config)
  // ------------------------------------------------------------

  /// عتبات النطاقات على مؤشر الانسجام.
  static const double alphaThreshold = 0.45;
  static const double thetaThreshold = 0.80;

  /// مهلة الإيقاف الذكي (PRD: 30 ثانية).
  static const Duration smartHaltTimeout = Duration(seconds: 30);

  /// سرعة الصعود الأساسية للانسجام (في الثانية) عند انتظام مثالي.
  static const double baseAscentRate = 1.0 / 240; // ≈ 4 دقائق من 0 إلى 1

  /// معدل تآكل الانسجام عند عدم الانتظام (نزول طفيف نحو بيتا).
  static const double decayRate = 1.0 / 900;

  /// نقاط طول الأثر لكل ثانية فعلية داخل كل نطاق (ثانية رصيد).
  static const double alphaEffectPerSecond = 0.8;
  static const double thetaEffectPerSecond = 2.0;

  /// نافذة حساب انتظام النقر (آخر N نقرات).
  static const int regularityWindow = 8;

  // ------------------------------------------------------------
  // الحالة الداخلية
  // ------------------------------------------------------------
  final DateTime _startTime;
  final List<double> _recentItiMs = []; // فواصل النقر الأخيرة (ms)
  DateTime? _lastTapAt;
  DateTime _lastTickAt = DateTime.now();

  double _coherence = 0;
  double _effectSeconds = 0;
  Duration _activeElapsed = Duration.zero;
  int _tapCount = 0;
  bool _halted = false;
  BrainwaveBand _band = BrainwaveBand.beta;
  BrainwaveBand? _pendingBandTransition;

  // ------------------------------------------------------------
  // المدخل 1: نقرة المستخدم
  // ------------------------------------------------------------
  void onTap(DateTime now) {
    if (_lastTapAt != null) {
      final iti = now.difference(_lastTapAt!).inMilliseconds.toDouble();
      // تجاهل الفواصل غير الواقعية (أقل من 150ms = اهتزاز يد،
      // وأكبر من مهلة الإيقاف = جلسة متقطعة).
      if (iti >= 150 && iti < smartHaltTimeout.inMilliseconds) {
        _recentItiMs.add(iti);
        if (_recentItiMs.length > regularityWindow) {
          _recentItiMs.removeAt(0);
        }
      }
    }
    _lastTapAt = now;
    _tapCount++;
    // استئناف من الإيقاف الذكي: النقرة تعيد تشغيل العداد.
    _halted = false;
  }

  // ------------------------------------------------------------
  // المدخل 2: نبضة الزمن — تُستدعى كل ~100ms من الواجهة
  // ------------------------------------------------------------
  SessionState tick(DateTime now) {
    final dtMs = now.difference(_lastTickAt).inMilliseconds;
    _lastTickAt = now;
    if (dtMs <= 0) return snapshot(now);
    final dt = dtMs / 1000.0;

    // ---- الإيقاف الذكي ----
    final sinceLastTap =
        _lastTapAt == null ? null : now.difference(_lastTapAt!);
    final shouldHalt = _tapCount > 0 &&
        sinceLastTap != null &&
        sinceLastTap >= smartHaltTimeout;

    if (shouldHalt) {
      // تجميد كامل: لا تراكم انسجام ولا طول أثر — دقة بيولوجية.
      _halted = true;
      return snapshot(now);
    }

    _activeElapsed += Duration(milliseconds: dtMs);

    // ---- انتظام النقر (1 - CV) ----
    final regularity = _computeRegularity();

    // ---- قيادة مؤشر الانسجام ----
    final inAlphaZone = _coherence >= alphaThreshold;
    final inThetaZone = _coherence >= thetaThreshold;

    // سرعة الصعود: مقاومة بيتا تعرقل البداية، وسرعة ثيتا تتحكم
    // في النصف الأعلى من المؤشر، وحساسية الدوبامين تضاعف المكافأة.
    var ascent = baseAscentRate * regularity;
    if (!inAlphaZone) {
      ascent /= modifiers.betaExitResistance;
    } else {
      ascent *= modifiers.thetaEntrySpeed;
      ascent *= modifiers.dopamineSensitivity;
    }

    // التآكل: كلما كان النقر غير منتظم، انزلق المؤشر نحو بيتا.
    // ثبات ألفا (كرياتين/زنك/زيت زيتون) يخفف التآكل داخل نطاق ألفا.
    var decay = decayRate * (1.0 - regularity);
    if (inAlphaZone && !inThetaZone) {
      decay /= modifiers.alphaStability;
    }

    _coherence = (_coherence + (ascent - decay) * dt).clamp(0.0, 1.0);

    // ---- احتساب طول الأثر ----
    // لا رصيد داخل بيتا؛ ألفا تمنح رصيداً معتدلاً؛ ثيتا تمنح الأعلى.
    final perSecond = inThetaZone
        ? thetaEffectPerSecond
        : inAlphaZone
            ? alphaEffectPerSecond
            : 0.0;
    _effectSeconds += perSecond * modifiers.effectMultiplier * dt;

    // ---- تحديد النطاق وتسجيل الانتقالات ----
    final newBand = _bandFor(_coherence);
    if (newBand != _band) {
      _pendingBandTransition = newBand;
      _band = newBand;
    }

    return snapshot(now);
  }

  // ------------------------------------------------------------
  // الإدخال بأثر رجعي (Offline Sync — PRD §5)
  // ------------------------------------------------------------
  /// يحاكي جلسة تمت خارج التطبيق بالاعتماد على المتوسط الإحصائي
  /// لسرعة نقر المستخدم. لا نختلق نقرات — نحسب الناتج الرياضي
  /// المكافئ مباشرة ونضيفه للرصيد.
  ///
  /// [tapCount] عدد التسبيحات المنجزة خارجياً (اختياري).
  /// [duration] مدة الجلسة الخارجية (اختياري).
  /// [avgItiMs] متوسط فاصل النقر التاريخي للمستخدم (مطلوب).
  ({Duration simulatedDuration, Duration effectGained}) applyRetroactive({
    int? tapCount,
    Duration? duration,
    required double avgItiMs,
  }) {
    // نحتاج واحداً من الاثنين على الأقل لاشتقاق الآخر.
    assert(tapCount != null || duration != null,
        'Provide at least tapCount or duration');

    final estDuration = duration ??
        Duration(milliseconds: ((tapCount ?? 0) * avgItiMs).round());

    // الانتظام المفترض للجلسة الخارجية: 0.7 (افتراض محافظ —
    // لا نملك بيانات فعلية، فلا نمنح انتظاماً مثالياً).
    const assumedRegularity = 0.7;

    // محاكاة رقمية بخطوات ثانية واحدة لضمان مطابقة منطق tick().
    var simCoherence = _coherence;
    var gained = 0.0;
    final seconds = estDuration.inSeconds;

    for (var s = 0; s < seconds; s++) {
      final inAlpha = simCoherence >= alphaThreshold;
      final inTheta = simCoherence >= thetaThreshold;

      var ascent = baseAscentRate * assumedRegularity;
      if (!inAlpha) {
        ascent /= modifiers.betaExitResistance;
      } else {
        ascent *= modifiers.thetaEntrySpeed * modifiers.dopamineSensitivity;
      }
      var decay = decayRate * (1.0 - assumedRegularity);
      if (inAlpha && !inTheta) decay /= modifiers.alphaStability;

      simCoherence = (simCoherence + ascent - decay).clamp(0.0, 1.0);

      final perSec =
          inTheta ? thetaEffectPerSecond : (inAlpha ? alphaEffectPerSecond : 0.0);
      gained += perSec * modifiers.effectMultiplier;
    }

    _coherence = simCoherence;
    _effectSeconds += gained;
    _activeElapsed += estDuration;

    return (
      simulatedDuration: estDuration,
      effectGained: Duration(seconds: gained.round()),
    );
  }

  // ------------------------------------------------------------
  // قراءة الحالة الحالية (Snapshot)
  // ------------------------------------------------------------
  SessionState snapshot(DateTime now) {
    final transition = _pendingBandTransition;
    _pendingBandTransition = null;
    return SessionState(
      band: _band,
      coherence: _coherence,
      simulatedHz: _simulatedHz(),
      elapsed: now.difference(_startTime),
      activeElapsed: _activeElapsed,
      tapCount: _tapCount,
      effectRemaining: Duration(seconds: _effectSeconds.round()),
      halted: _halted,
      regularity: _computeRegularity(),
      suggestedDhikr: modifiers.suggestedDhikr,
      recommendLoudMode: modifiers.recommendLoudMode,
      needsAlertnessDhikr: modifiers.needsAlertnessDhikr,
      justEnteredBand: transition,
    );
  }

  /// المتوسط الإحصائي لسرعة نقر المستخدم (ms) — يُخزَّن طويلاً
  /// في SharedPreferences ليغذي الإدخال بأثر رجعي.
  double? get averageItiMs => _recentItiMs.isEmpty
      ? null
      : _recentItiMs.reduce((a, b) => a + b) / _recentItiMs.length;

  // ------------------------------------------------------------
  // دوال داخلية
  // ------------------------------------------------------------
  BrainwaveBand _bandFor(double coherence) {
    if (coherence >= thetaThreshold) return BrainwaveBand.theta;
    if (coherence >= alphaThreshold) return BrainwaveBand.alpha;
    return BrainwaveBand.beta;
  }

  /// الانتظام = 1 - معامل الاختلاف (CV) لفواصل النقر، مقيداً بـ [0,1].
  /// CV منخفض = إيقاع ثابت = انتظام عالٍ.
  double _computeRegularity() {
    if (_recentItiMs.length < 3) {
      // بيانات غير كافية: نعطي قيمة تأسيسية متواضعة حتى لا يتجمد المؤشر.
      return _recentItiMs.isEmpty ? 0.0 : 0.4;
    }
    final mean =
        _recentItiMs.reduce((a, b) => a + b) / _recentItiMs.length;
    final variance = _recentItiMs
            .map((x) => math.pow(x - mean, 2).toDouble())
            .reduce((a, b) => a + b) /
        _recentItiMs.length;
    final cv = math.sqrt(variance) / mean;
    return (1.0 - cv).clamp(0.0, 1.0);
  }

  /// التردد المحاكى المعروض: ينزلق داخل نطاق النطاق الحالي
  /// كلما ارتفع الانسجام اقترب من الحد الأدنى للتردد (أعمق).
  double _simulatedHz() {
    final (minHz, maxHz) = _band.hzRange;
    final (lo, hi) = switch (_band) {
      BrainwaveBand.beta => (0.0, alphaThreshold),
      BrainwaveBand.alpha => (alphaThreshold, thetaThreshold),
      BrainwaveBand.theta => (thetaThreshold, 1.0),
    };
    final t = ((_coherence - lo) / (hi - lo)).clamp(0.0, 1.0);
    return maxHz - t * (maxHz - minHz);
  }
}
