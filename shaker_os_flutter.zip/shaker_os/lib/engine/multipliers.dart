/// =============================================================
/// Shaker OS — حاسبة المُعاملات (Multipliers Engine)
/// =============================================================
/// تحوّل "الاستبيان الاختياري" (UserInputs) إلى حزمة مُعاملات
/// عددية واحدة يستهلكها المحرك الأساسي. كل قاعدة هنا مرتبطة
/// مباشرة ببند في وثيقة الـ PRD (القسم 3).
library;

import 'dart:math' as math;

import 'models/session_models.dart';

/// حزمة المُعاملات العددية الناتجة عن تحليل مُدخلات المستخدم.
///
/// القاعدة العامة: 1.0 = لا تأثير. أكبر من 1 = تسريع/تضخيم،
/// أصغر من 1 = تثبيط/مقاومة.
class EngineModifiers {
  const EngineModifiers({
    this.betaExitResistance = 1.0,
    this.thetaEntrySpeed = 1.0,
    this.alphaStability = 1.0,
    this.effectMultiplier = 1.0,
    this.startCoherence = 0.0,
    this.instantCoherenceBoost = 0.0,
    this.dopamineSensitivity = 1.0,
    this.suggestedDhikr = const [],
    this.recommendLoudMode = false,
    this.needsAlertnessDhikr = false,
  });

  /// مقاومة الخروج من بيتا (>1 = نزول أبطأ، <1 = كسر أسرع للتوتر).
  final double betaExitResistance;

  /// سرعة الدخول إلى ثيتا العميقة (>1 = أسرع).
  final double thetaEntrySpeed;

  /// ثبات ألفا اليقظة (>1 = تذبذب أقل، مفيد للجلسات الطويلة).
  final double alphaStability;

  /// مُضاعف نقاط "طول الأثر" (السجود الطويل = ×5).
  final double effectMultiplier;

  /// نقطة بداية مؤشر الانسجام (0..1) — تتأثر بالقرآن/القيام المسبق.
  final double startCoherence;

  /// دفعة انسجام فورية لمرة واحدة عند بدء الجلسة (صيام/صدقة).
  final double instantCoherenceBoost;

  /// حساسية الدوبامين (تنمو مع أيام الاحتفاظ X).
  final double dopamineSensitivity;

  /// الأذكار المقترحة كأولوية بناءً على الحالة.
  final List<String> suggestedDhikr;

  /// هل يقترح التطبيق الجهر لكسر التوتر؟ (كافيين/توتر شديد)
  final bool recommendLoudMode;

  /// هل المستخدم متعب ويحتاج أذكار يقظة؟
  final bool needsAlertnessDhikr;

  /// دمج مُعامل خارجي (مثل Bio-Clock) فوق هذه الحزمة.
  EngineModifiers merge(EngineModifiers other) => EngineModifiers(
        betaExitResistance: betaExitResistance * other.betaExitResistance,
        thetaEntrySpeed: thetaEntrySpeed * other.thetaEntrySpeed,
        alphaStability: alphaStability * other.alphaStability,
        effectMultiplier: effectMultiplier * other.effectMultiplier,
        startCoherence: math.max(startCoherence, other.startCoherence),
        instantCoherenceBoost:
            instantCoherenceBoost + other.instantCoherenceBoost,
        dopamineSensitivity: dopamineSensitivity * other.dopamineSensitivity,
        suggestedDhikr: {...suggestedDhikr, ...other.suggestedDhikr}.toList(),
        recommendLoudMode: recommendLoudMode || other.recommendLoudMode,
        needsAlertnessDhikr: needsAlertnessDhikr || other.needsAlertnessDhikr,
      );
}

/// الدالة الرئيسية: تبني المُعاملات من مُدخلات المستخدم.
EngineModifiers computeModifiers(UserInputs input) {
  var m = const EngineModifiers();

  // ---------------------------------------------------------
  // أ. الحالة النفسية (PRD §3.أ)
  // ---------------------------------------------------------
  switch (input.psychological) {
    case PsychologicalState.stressed:
      // بيتا العالي: نُبطئ النزول ليكون منطقياً + أذكار التفريغ.
      m = m.merge(const EngineModifiers(
        betaExitResistance: 1.6,
        suggestedDhikr: [
          'أستغفر الله العظيم وأتوب إليه',
          'لا حول ولا قوة إلا بالله',
        ],
        recommendLoudMode: true,
      ));
    case PsychologicalState.tired:
      // ميل نحو دلتا (النعاس): أذكار تنشيط ويقظة.
      m = m.merge(const EngineModifiers(
        betaExitResistance: 0.9,
        needsAlertnessDhikr: true,
        suggestedDhikr: [
          'سبحان الله وبحمده',
          'الله أكبر',
        ],
      ));
    case PsychologicalState.relaxed:
      // الدماغ في ألفا أصلاً: تسريع الدخول في ثيتا.
      m = m.merge(const EngineModifiers(
        startCoherence: 0.30,
        thetaEntrySpeed: 1.4,
      ));
    case PsychologicalState.grateful:
      // امتنان: كالاسترخاء مع دفعة تماسك إضافية.
      m = m.merge(const EngineModifiers(
        startCoherence: 0.35,
        thetaEntrySpeed: 1.5,
        suggestedDhikr: ['الحمد لله رب العالمين'],
      ));
    case PsychologicalState.neutral:
      break;
  }

  // ---------------------------------------------------------
  // ب. الحالة الفيزيائية والصوتية (PRD §3.ب)
  // ---------------------------------------------------------
  switch (input.physical) {
    case PhysicalMode.loud:
      // الجهر يحفّز العصب المبهم ميكانيكياً → كسر سريع لحاجز بيتا.
      m = m.merge(const EngineModifiers(betaExitResistance: 0.6));
    case PhysicalMode.whisper:
      // الهمس يعزل الحواس الخارجية → غوص أسرع في ثيتا.
      m = m.merge(const EngineModifiers(thetaEntrySpeed: 1.5));
    case PhysicalMode.longSujood:
      // السجود الطويل: ×5 على نقاط طول الأثر، مُرجّحة بنسبة
      // الالتزام الفعلي (ذكر/دعاء) من إجمالي وقت السجود.
      final engagement = input.sujood?.engagementRatio ?? 0.5;
      final boost = 1.0 + 4.0 * (0.5 + 0.5 * engagement); // من ×3 إلى ×5
      m = m.merge(EngineModifiers(
        effectMultiplier: boost,
        thetaEntrySpeed: 1.3, // تدفق الأكسجين للفص الجبهي
      ));
    case PhysicalMode.silent:
      break;
  }

  // ---------------------------------------------------------
  // ج. الكيمياء الحيوية والمكملات (PRD §3.ج)
  // ---------------------------------------------------------
  for (final s in input.supplements) {
    switch (s) {
      case Supplement.caffeine:
        // مقاومة كيميائية: لا نزول سريع من بيتا + اقتراح الجهر.
        m = m.merge(const EngineModifiers(
          betaExitResistance: 1.8,
          recommendLoudMode: true,
        ));
      case Supplement.magnesiumGlycinate:
        // درع استقرار: تسريع ثيتا + انسجام دماغي.
        m = m.merge(const EngineModifiers(
          thetaEntrySpeed: 1.3,
          instantCoherenceBoost: 0.05,
        ));
      case Supplement.omega3:
        m = m.merge(const EngineModifiers(thetaEntrySpeed: 1.25));
      case Supplement.creatine:
        // منع الإرهاق الذهني: تثبيت ألفا للجلسات الطويلة.
        m = m.merge(const EngineModifiers(alphaStability: 1.3));
      case Supplement.zinc:
        m = m.merge(const EngineModifiers(alphaStability: 1.15));
      case Supplement.oliveOil:
        m = m.merge(const EngineModifiers(alphaStability: 1.1));
    }
  }

  // ---------------------------------------------------------
  // د. الهرمونات وحساسية الدوبامين (PRD §3.د)
  // ---------------------------------------------------------
  // كل يوم احتفاظ (X) يرفع حساسية الدوبامين بنسبة 3% (بحد أقصى
  // 30 يوماً)، فيُسرَّع النزول إلى ثيتا وتُضاعف نقاط الاستقرار.
  final days = input.retentionDays.clamp(0, 30);
  final dopamine = 1.0 + days * 0.03;
  final rewardBoost = 1.0 + days * 0.02;
  m = m.merge(EngineModifiers(
    dopamineSensitivity: dopamine,
    thetaEntrySpeed: 1.0 + (dopamine - 1.0) * 0.8,
    effectMultiplier: rewardBoost,
  ));

  // ---------------------------------------------------------
  // هـ. المنظومة الروحية (PRD §3.هـ)
  // ---------------------------------------------------------
  if (input.isFasting) {
    // صيام: انسجام دماغي فوري (أوكسيتوسين/سيروتونين).
    m = m.merge(const EngineModifiers(
      instantCoherenceBoost: 0.15,
      thetaEntrySpeed: 1.2,
    ));
  }
  if (input.gaveCharity) {
    m = m.merge(const EngineModifiers(
      instantCoherenceBoost: 0.12,
      startCoherence: 0.10,
    ));
  }
  if (input.quranStatus == WorshipTiming.doneBefore) {
    // قرآن مسبق: يرفع نقطة البداية على المؤشر.
    m = m.merge(const EngineModifiers(startCoherence: 0.15));
  }
  if (input.qiyamStatus == WorshipTiming.doneBefore) {
    m = m.merge(const EngineModifiers(startCoherence: 0.20));
  }
  if (input.qiyamStatus == WorshipTiming.plannedLater) {
    // قيام لاحق: أولوية لأذكار تمهّد للقيام.
    m = m.merge(const EngineModifiers(
      suggestedDhikr: ['اللهم أعني على ذكرك وشكرك وحسن عبادتك'],
    ));
  }

  // ---------------------------------------------------------
  // أغطية أمان (Clamps) لمنع أي انفجار عددي
  // ---------------------------------------------------------
  return EngineModifiers(
    betaExitResistance: m.betaExitResistance.clamp(0.4, 3.0),
    thetaEntrySpeed: m.thetaEntrySpeed.clamp(0.5, 4.0),
    alphaStability: m.alphaStability.clamp(0.5, 2.5),
    effectMultiplier: m.effectMultiplier.clamp(1.0, 8.0),
    startCoherence: m.startCoherence.clamp(0.0, 0.55),
    instantCoherenceBoost: m.instantCoherenceBoost.clamp(0.0, 0.40),
    dopamineSensitivity: m.dopamineSensitivity.clamp(1.0, 2.0),
    suggestedDhikr: m.suggestedDhikr,
    recommendLoudMode: m.recommendLoudMode,
    needsAlertnessDhikr: m.needsAlertnessDhikr,
  );
}
