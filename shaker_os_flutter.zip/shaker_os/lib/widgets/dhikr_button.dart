/// =============================================================
/// Shaker OS — زر الذكر الديناميكي (Dhikr Button)
/// =============================================================
/// زر كبير قابل لتخصيص النص، بنبض بصري يتنفس مع مؤشر الانسجام
/// ويستجيب لحظياً لكل نقرة.
library;

import 'package:flutter/material.dart';

class DhikrButton extends StatefulWidget {
  const DhikrButton({
    super.key,
    required this.label,
    required this.onTap,
    required this.coherence,
    required this.accentColor,
    required this.textColor,
  });

  /// النص المخصص على الزر (مثلاً: سبحان الله).
  final String label;
  final VoidCallback onTap;

  /// 0..1 — يقود توهج الزر وحلقته الخارجية.
  final double coherence;

  final Color accentColor;
  final Color textColor;

  @override
  State<DhikrButton> createState() => _DhikrButtonState();
}

class _DhikrButtonState extends State<DhikrButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 260),
      lowerBound: 0.95,
      upperBound: 1.0,
      value: 1.0,
    );
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  void _handleTap() {
    widget.onTap();
    _pulse.forward(from: 0.95);
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context).width * 0.62;
    final glow = widget.coherence;

    return GestureDetector(
      onTap: _handleTap,
      child: ScaleTransition(
        scale: _pulse,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 400),
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: widget.accentColor.withValues(alpha: 0.08 + glow * 0.12),
            border: Border.all(
              color: widget.accentColor.withValues(alpha: 0.4 + glow * 0.6),
              width: 2.5,
            ),
            boxShadow: [
              BoxShadow(
                color: widget.accentColor.withValues(alpha: glow * 0.45),
                blurRadius: 40 + glow * 60,
                spreadRadius: 4 + glow * 10,
              ),
            ],
          ),
          alignment: Alignment.center,
          child: Text(
            widget.label,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: widget.textColor,
              fontSize: 26,
              fontWeight: FontWeight.w600,
              height: 1.4,
            ),
          ),
        ),
      ),
    );
  }
}
