/// =============================================================
/// Shaker OS — شريط التوكيدات (Affirmations Carousel)
/// =============================================================
/// شريط علوي يعرض عبارات تشجيعية بالتناوب التلقائي، ويعرض
/// رسائل تفاعلية خاصة عند الانتقال إلى ألفا أو ثيتا (PRD §4).
library;

import 'dart:async';

import 'package:flutter/material.dart';

import '../../engine/models/session_models.dart';

class AffirmationCarousel extends StatefulWidget {
  const AffirmationCarousel({
    super.key,
    required this.band,
    required this.transition,
    required this.suggestedDhikr,
    required this.textColor,
    required this.accentColor,
  });

  final BrainwaveBand band;

  /// نطاق دخل إليه المستخدم للتو (للرسائل التفاعلية).
  final BrainwaveBand? transition;

  /// أذكار مقترحة من الخوارزمية (لها أولوية العرض).
  final List<String> suggestedDhikr;

  final Color textColor;
  final Color accentColor;

  @override
  State<AffirmationCarousel> createState() => _AffirmationCarouselState();
}

class _AffirmationCarouselState extends State<AffirmationCarousel> {
  /// العبارات الافتراضية — لاحقاً تُسحب من مجلد المستخدم المخصص.
  static const _defaults = [
    'كل نقرة واعية تُعيد ضبط جهازك العصبي',
    'السكينة تُبنى نبضةً فوق نبضة',
    'أنت لا تعدّ التسبيحات، بل تزرع الاستقرار',
    'التنفس البطيء مع الذكر يضاعف الأثر',
    'استمر — دماغك يتعلم طريق العودة إلى الهدوء',
  ];

  Timer? _timer;
  int _index = 0;
  String? _transientMessage;

  @override
  void initState() {
    super.initState();
    _timer = Timer.periodic(const Duration(seconds: 6), (_) {
      if (!mounted) return;
      setState(() {
        _transientMessage = null;
        _index = (_index + 1) % _pool.length;
      });
    });
  }

  @override
  void didUpdateWidget(AffirmationCarousel old) {
    super.didUpdateWidget(old);
    if (widget.transition != null && widget.transition != old.transition) {
      // رسالة تفاعلية عند الوصول لنطاق جديد (تظهر 6 ثوانٍ).
      setState(() {
        _transientMessage = switch (widget.transition!) {
          BrainwaveBand.alpha => 'دخلت نطاق ألفا — التناغم بدأ',
          BrainwaveBand.theta => 'ثيتا العميقة — طور التشافي نشط الآن',
          BrainwaveBand.beta => null,
        };
      });
    }
  }

  List<String> get _pool =>
      widget.suggestedDhikr.isNotEmpty ? widget.suggestedDhikr : _defaults;

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final message = _transientMessage ?? _pool[_index % _pool.length];
    final isTransient = _transientMessage != null;

    return AnimatedSwitcher(
      duration: const Duration(milliseconds: 500),
      child: Container(
        key: ValueKey(message),
        width: double.infinity,
        margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        decoration: BoxDecoration(
          color: isTransient
              ? widget.accentColor.withValues(alpha: 0.15)
              : widget.accentColor.withValues(alpha: 0.06),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isTransient
                ? widget.accentColor.withValues(alpha: 0.5)
                : widget.accentColor.withValues(alpha: 0.12),
          ),
        ),
        child: Text(
          message,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: isTransient ? widget.accentColor : widget.textColor,
            fontSize: 14,
            height: 1.6,
          ),
        ),
      ),
    );
  }
}
