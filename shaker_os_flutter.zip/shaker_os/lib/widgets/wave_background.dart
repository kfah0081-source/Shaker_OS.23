/// =============================================================
/// Shaker OS — خلفية الموجات الحية (Wave Background)
/// =============================================================
/// CustomPainter يرسم 3 طبقات موجات جيبية. تردد الموجة وسعتها
/// يتبعان النطاق الدماغي الحالي: بيتا = موجات سريعة حادة،
/// ثيتا = موجات بطيئة واسعة تتنفس.
library;

import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../engine/models/session_models.dart';

class WaveBackground extends StatefulWidget {
  const WaveBackground({
    super.key,
    required this.band,
    required this.coherence,
    required this.waveColors,
  });

  final BrainwaveBand band;
  final double coherence;
  final List<Color> waveColors;

  @override
  State<WaveBackground> createState() => _WaveBackgroundState();
}

class _WaveBackgroundState extends State<WaveBackground>
    with SingleTickerProviderStateMixin {
  late final AnimationController _anim;

  @override
  void initState() {
    super.initState();
    // دورة رسوم مستمرة — السرعة الفعلية تُضبط حسب النطاق.
    _anim = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();
  }

  @override
  void didUpdateWidget(WaveBackground old) {
    super.didUpdateWidget(old);
    if (old.band != widget.band) {
      // بيتا أسرع (أقصر دورة)، ثيتا أبطأ (أطول دورة) — "تنفّس".
      _anim.duration = switch (widget.band) {
        BrainwaveBand.beta => const Duration(seconds: 2),
        BrainwaveBand.alpha => const Duration(seconds: 4),
        BrainwaveBand.theta => const Duration(seconds: 8),
      };
      _anim.repeat();
    }
  }

  @override
  void dispose() {
    _anim.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return RepaintBoundary(
      child: AnimatedBuilder(
        animation: _anim,
        builder: (context, _) => CustomPaint(
          size: Size.infinite,
          painter: _WavePainter(
            phase: _anim.value * 2 * math.pi,
            coherence: widget.coherence,
            band: widget.band,
            colors: widget.waveColors,
          ),
        ),
      ),
    );
  }
}

class _WavePainter extends CustomPainter {
  _WavePainter({
    required this.phase,
    required this.coherence,
    required this.band,
    required this.colors,
  });

  final double phase;
  final double coherence;
  final BrainwaveBand band;
  final List<Color> colors;

  @override
  void paint(Canvas canvas, Size size) {
    // عدد القمم لكل موجة: بيتا مزدحمة، ثيتا ممتدة.
    final frequencyFactor = switch (band) {
      BrainwaveBand.beta => 3.0,
      BrainwaveBand.alpha => 2.0,
      BrainwaveBand.theta => 1.0,
    };
    // السعة تكبر مع الانسجام (الموجة "تتنفس" أكثر في العمق).
    final amplitude = size.height * (0.04 + coherence * 0.10);

    for (var layer = 0; layer < colors.length; layer++) {
      final paint = Paint()
        ..color = colors[layer]
        ..style = PaintingStyle.fill;

      final layerPhase = phase * (1.0 + layer * 0.35) + layer * 1.2;
      final baseY = size.height * (0.55 + layer * 0.12);

      final path = Path()..moveTo(0, size.height);
      for (var x = 0.0; x <= size.width; x += 4) {
        final t = x / size.width;
        final y = baseY +
            math.sin(t * math.pi * 2 * frequencyFactor + layerPhase) *
                amplitude +
            math.sin(t * math.pi * 6 + layerPhase * 1.7) * amplitude * 0.25;
        path.lineTo(x, y);
      }
      path
        ..lineTo(size.width, size.height)
        ..close();
      canvas.drawPath(path, paint);
    }
  }

  @override
  bool shouldRepaint(_WavePainter old) =>
      old.phase != phase ||
      old.coherence != coherence ||
      old.band != band;
}
