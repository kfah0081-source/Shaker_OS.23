import 'package:flutter_test/flutter_test.dart';
import 'package:shaker_os/engine/brainwave_engine.dart';
import 'package:shaker_os/engine/models/session_models.dart';
import 'package:shaker_os/engine/multipliers.dart';

void main() {
  group('BrainwaveEngine', () {
    test('النقر المنتظم يرفع الانسجام وينقل النطاق من بيتا إلى ألفا', () {
      final engine = BrainwaveEngine(modifiers: const EngineModifiers());
      var t = DateTime(2026, 1, 1, 12);

      // محاكاة نقر منتظم كل 800ms لمدة 5 دقائق.
      final end = t.add(const Duration(minutes: 5));
      var nextTap = t;
      late SessionState s;
      while (t.isBefore(end)) {
        if (!t.isBefore(nextTap)) {
          engine.onTap(t);
          nextTap = nextTap.add(const Duration(milliseconds: 800));
        }
        s = engine.tick(t);
        t = t.add(const Duration(milliseconds: 100));
      }
      s = engine.snapshot(t);

      expect(s.regularity, greaterThan(0.9));
      expect(s.band, isNot(BrainwaveBand.beta));
      expect(s.effectRemaining.inSeconds, greaterThan(0));
    });

    test('الإيقاف الذكي يجمّد العداد بعد 30 ثانية من الصمت', () {
      final engine = BrainwaveEngine(modifiers: const EngineModifiers());
      var t = DateTime(2026, 1, 1, 12);

      engine.onTap(t);
      t = t.add(const Duration(seconds: 31));
      final s = engine.tick(t);

      expect(s.halted, isTrue);

      // الاستئناف بنقرة.
      engine.onTap(t);
      final resumed = engine.tick(t);
      expect(resumed.halted, isFalse);
    });

    test('التوتر + الكافيين يبطئان الخروج من بيتا مقارنة بالمحايد', () {
      SessionState simulate(EngineModifiers m) {
        final engine = BrainwaveEngine(modifiers: m);
        var t = DateTime(2026, 1, 1, 12);
        final end = t.add(const Duration(minutes: 2));
        var nextTap = t;
        while (t.isBefore(end)) {
          if (!t.isBefore(nextTap)) {
            engine.onTap(t);
            nextTap = nextTap.add(const Duration(milliseconds: 800));
          }
          engine.tick(t);
          t = t.add(const Duration(milliseconds: 100));
        }
        return engine.snapshot(t);
      }

      final neutral = simulate(const EngineModifiers());
      final resistant = simulate(computeModifiers(const UserInputs(
        psychological: PsychologicalState.stressed,
        supplements: {Supplement.caffeine},
      )));

      expect(resistant.coherence, lessThan(neutral.coherence));
    });

    test('السجود الطويل يضاعف طول الأثر', () {
      SessionState simulate(EngineModifiers m) {
        final engine = BrainwaveEngine(modifiers: m);
        var t = DateTime(2026, 1, 1, 12);
        final end = t.add(const Duration(minutes: 6));
        var nextTap = t;
        while (t.isBefore(end)) {
          if (!t.isBefore(nextTap)) {
            engine.onTap(t);
            nextTap = nextTap.add(const Duration(milliseconds: 800));
          }
          engine.tick(t);
          t = t.add(const Duration(milliseconds: 100));
        }
        return engine.snapshot(t);
      }

      final normal = simulate(const EngineModifiers());
      final sujood = simulate(computeModifiers(const UserInputs(
        physical: PhysicalMode.longSujood,
        sujood: SujoodDetails(
          totalDuration: Duration(minutes: 10),
          dhikrDuration: Duration(minutes: 6),
          duaDuration: Duration(minutes: 4),
        ),
      )));

      expect(
        sujood.effectRemaining.inSeconds,
        greaterThan(normal.effectRemaining.inSeconds * 2),
      );
    });

    test('الإدخال بأثر رجعي يضيف رصيداً متسقاً مع منطق الجلسة الحية', () {
      final engine = BrainwaveEngine(modifiers: const EngineModifiers());
      final result = engine.applyRetroactive(
        tapCount: 300,
        avgItiMs: 900,
      );

      expect(result.simulatedDuration.inMinutes, greaterThanOrEqualTo(4));
      expect(result.effectGained.inSeconds, greaterThan(0));

      final s = engine.snapshot(DateTime.now());
      expect(s.effectRemaining.inSeconds,
          equals(result.effectGained.inSeconds));
    });
  });
}
